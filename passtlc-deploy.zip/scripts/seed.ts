import bcrypt from "bcryptjs";
import {
  upsertCategory,
  findQuestionByPrompt,
  createQuestion,
  upsertAdminUser,
  countReviews,
  insertReviewSeed,
} from "../src/lib/repo";

// Original practice content written for this project. Category names mirror
// the publicly known subject areas of the NYC TLC licensing exam (facts, not
// anyone's copyrighted expression); question wording and explanations below
// are original.
const categories = [
  {
    slug: "customer-service",
    name: "Customer Service",
    summary: "Professional conduct, courtesy, and handling passenger situations.",
    questions: [
      {
        prompt: "A passenger asks you to take a specific route you know is slower. What should you do?",
        choices: [
          "Take your own preferred route instead",
          "Take the route the passenger requested",
          "Refuse the trip",
          "Charge an extra fee before starting",
        ],
        answer: 1,
        explanation: "Passengers have the right to request their preferred route; drivers should accommodate reasonable requests.",
      },
      {
        prompt: "What is the appropriate way to assist a passenger with a visible disability?",
        choices: [
          "Ignore the request unless asked directly",
          "Offer reasonable assistance, such as helping with mobility devices, if requested",
          "Decline the trip",
          "Charge an additional service fee",
        ],
        answer: 1,
        explanation: "Drivers are expected to provide reasonable, respectful assistance to passengers who request it.",
      },
      {
        prompt: "A passenger leaves a personal item in the vehicle. What is the correct first step?",
        choices: [
          "Keep the item",
          "Drop it off at any police precinct only",
          "Attempt to return it to the passenger or report it through the proper lost-and-found process",
          "Leave it on the street",
        ],
        answer: 2,
        explanation: "Drivers should make a reasonable effort to return lost property or follow the designated lost-and-found procedure.",
      },
    ],
  },
  {
    slug: "geography-1",
    name: "Geography 1",
    summary: "Manhattan landmarks, avenues, and navigation basics.",
    questions: [
      {
        prompt: "Which borough is directly across the East River from Midtown Manhattan?",
        choices: ["The Bronx", "Queens", "Staten Island", "New Jersey"],
        answer: 1,
        explanation: "Queens sits across the East River from Midtown Manhattan.",
      },
      {
        prompt: "Numbered avenues in Manhattan generally run in which direction?",
        choices: ["East-west", "North-south", "Diagonally only", "They don't run in a consistent direction"],
        answer: 1,
        explanation: "Manhattan's numbered avenues run north-south, while numbered streets run east-west.",
      },
    ],
  },
  {
    slug: "geography-2",
    name: "Geography 2",
    summary: "Outer-borough routes and major crossings.",
    questions: [
      {
        prompt: "Which bridge connects Manhattan to Brooklyn near the southern tip of Manhattan?",
        choices: ["George Washington Bridge", "Brooklyn Bridge", "Throgs Neck Bridge", "Whitestone Bridge"],
        answer: 1,
        explanation: "The Brooklyn Bridge connects Lower Manhattan to Brooklyn.",
      },
      {
        prompt: "Which crossing connects Staten Island to Brooklyn?",
        choices: ["Verrazzano-Narrows Bridge", "Queensboro Bridge", "Triborough Bridge", "Manhattan Bridge"],
        answer: 0,
        explanation: "The Verrazzano-Narrows Bridge links Staten Island and Brooklyn.",
      },
    ],
  },
  {
    slug: "safe-driving",
    name: "Safe driving skills and traffic rules",
    summary: "Defensive driving, right-of-way, and NYC traffic rules.",
    questions: [
      {
        prompt: "When approaching a pedestrian in a crosswalk with no traffic signal, a driver must:",
        choices: [
          "Speed up to pass before they step off the curb",
          "Yield the right-of-way to the pedestrian",
          "Honk to warn them away",
          "Only yield if the pedestrian is already halfway across",
        ],
        answer: 1,
        explanation: "Drivers must yield to pedestrians in a crosswalk, signal or no signal.",
      },
      {
        prompt: "What following distance is generally recommended in normal traffic conditions?",
        choices: ["As close as possible to save time", "About one car length total", "At least a few seconds of following distance", "None, as long as brakes work"],
        answer: 2,
        explanation: "A multi-second following distance gives time to react to sudden stops.",
      },
    ],
  },
  {
    slug: "tlc-rules-1",
    name: "TLC rules and regulations 1",
    summary: "Licensing requirements and vehicle standards.",
    questions: [
      {
        prompt: "A for-hire vehicle license must generally be:",
        choices: [
          "Displayed as required and kept current",
          "Optional if the driver has a regular license",
          "Only needed for airport trips",
          "Renewed only if requested by a passenger",
        ],
        answer: 0,
        explanation: "Licensed for-hire vehicles must display valid licensing as required by regulation.",
      },
    ],
  },
  {
    slug: "tlc-rules-2",
    name: "TLC rules and regulations 2",
    summary: "Fares, records, and passenger rights.",
    questions: [
      {
        prompt: "Refusing a passenger based on their destination, when the trip is within the vehicle's permitted service area, is generally:",
        choices: ["Allowed at the driver's discretion", "Not allowed", "Allowed only at night", "Allowed only in bad weather"],
        answer: 1,
        explanation: "Drivers generally may not refuse passengers based solely on destination within their permitted service area.",
      },
    ],
  },
  {
    slug: "vision-zero",
    name: "Vision Zero",
    summary: "NYC's street-safety initiative and its impact on driving practices.",
    questions: [
      {
        prompt: "Vision Zero is a NYC initiative primarily focused on:",
        choices: [
          "Reducing traffic-related deaths and severe injuries",
          "Reducing subway fares",
          "Increasing highway speed limits",
          "Expanding parking availability",
        ],
        answer: 0,
        explanation: "Vision Zero aims to eliminate traffic deaths and severe injuries through safer street design and enforcement.",
      },
    ],
  },
];

async function main() {
  categories.forEach((c, i) => {
    const category = upsertCategory(c.slug, c.name, c.summary, i);
    for (const q of c.questions) {
      if (!findQuestionByPrompt(category.id, q.prompt)) {
        createQuestion({
          categoryId: category.id,
          prompt: q.prompt,
          choices: q.choices,
          answer: q.answer,
          explanation: q.explanation,
        });
      }
    }
  });

  const adminEmail = process.env.ADMIN_EMAIL || "admin@passtlc.com";
  const adminPassword = process.env.ADMIN_PASSWORD || "PassTLC-Admin!2026";
  const passwordHash = await bcrypt.hash(adminPassword, 10);
  upsertAdminUser(adminEmail, passwordHash);

  if (countReviews() === 0) {
    insertReviewSeed({ name: "Jasmine R.", body: "The practice exams matched the real test topics closely. Passed on my first attempt.", rating: 5 });
    insertReviewSeed({ name: "Marcus T.", body: "Clear explanations for wrong answers helped me actually understand the rules, not just memorize.", rating: 5 });
    insertReviewSeed({ name: "Aisha K.", body: "Used the free trial first, then subscribed once I saw how it tracked my weak categories.", rating: 4 });
  }

  console.log("Seed complete.");
  console.log(`Admin login -> email: ${adminEmail}  password: ${adminPassword}`);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
