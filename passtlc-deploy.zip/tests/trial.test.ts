import { describe, it, expect } from "vitest";
import {
  FREE_TRIAL_QUESTION_LIMIT,
  hasFullAccess,
  remainingTrialQuestions,
  canAnswerAnotherQuestion,
} from "../src/lib/trial";

describe("trial limit logic", () => {
  it("gives full anonymous users the full limit remaining", () => {
    expect(remainingTrialQuestions(null)).toBe(FREE_TRIAL_QUESTION_LIMIT);
  });

  it("counts down remaining questions", () => {
    expect(remainingTrialQuestions({ questionsAnswered: 10 })).toBe(40);
  });

  it("never goes negative", () => {
    expect(remainingTrialQuestions({ questionsAnswered: 999 })).toBe(0);
  });

  it("blocks further answers once the limit is hit for non-subscribers", () => {
    expect(
      canAnswerAnotherQuestion({ questionsAnswered: 50, subscriptionStatus: "NONE" })
    ).toBe(false);
  });

  it("always allows active subscribers regardless of count", () => {
    expect(
      canAnswerAnotherQuestion({ questionsAnswered: 500, subscriptionStatus: "ACTIVE" })
    ).toBe(true);
    expect(hasFullAccess({ subscriptionStatus: "ACTIVE" })).toBe(true);
    expect(hasFullAccess({ subscriptionStatus: "CANCELED" })).toBe(false);
  });
});
