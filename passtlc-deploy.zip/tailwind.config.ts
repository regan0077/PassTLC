import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        ink: "#0F1F33",
        paper: "#F3F5F4",
        taxi: "#FFC627",
        signal: "#1B7A43",
        alert: "#C6402B",
        slate: "#5B6472",
      },
      fontFamily: {
        display: ["Arial Black", "Helvetica Neue", "Arial", "sans-serif"],
        body: [
          "-apple-system",
          "BlinkMacSystemFont",
          "Segoe UI",
          "Roboto",
          "Helvetica",
          "Arial",
          "sans-serif",
        ],
      },
      maxWidth: {
        prose: "68ch",
      },
    },
  },
  plugins: [],
};
export default config;
