import Link from "next/link";

export default function Footer() {
  return (
    <footer className="mt-16 border-t border-[#d7dbd9] bg-white">
      <div className="container-page grid gap-8 py-10 md:grid-cols-3">
        <div>
          <div className="font-display text-lg font-bold">PassTLC</div>
          <p className="mt-2 max-w-prose font-body text-sm text-slate">
            Independent TLC license exam practice. Not affiliated with the NYC
            Taxi and Limousine Commission.
          </p>
        </div>
        <div className="font-body text-sm">
          <div className="font-bold">Practice</div>
          <ul className="mt-2 space-y-1 text-slate">
            <li><Link href="/exam">All categories</Link></li>
            <li><Link href="/pricing">Full access</Link></li>
            <li><Link href="/reviews">Reviews</Link></li>
          </ul>
        </div>
        <div className="font-body text-sm">
          <div className="font-bold">Support</div>
          <ul className="mt-2 space-y-1 text-slate">
            <li><Link href="/contact">Contact us</Link></li>
            <li><Link href="/signin">Sign in</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-[#d7dbd9] py-4 text-center font-body text-xs text-slate">
        © {new Date().getFullYear()} PassTLC. All rights reserved.
      </div>
    </footer>
  );
}
