import Link from "next/link";
import { getCurrentUser } from "@/lib/auth";

export default async function Navbar() {
  const user = await getCurrentUser().catch(() => null);

  return (
    <header className="border-b border-[#d7dbd9] bg-white">
      <div className="container-page flex h-16 items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          <svg width="30" height="30" viewBox="0 0 48 48" aria-hidden="true">
            <path d="M24 2 L44 10 V24 C44 36 36 43 24 46 C12 43 4 36 4 24 V10 Z" fill="#0F1F33" />
            <path d="M15 24 L21 30 L33 16" stroke="#FFC627" strokeWidth="4" fill="none" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          <span className="font-display text-xl font-bold tracking-tight">PassTLC</span>
        </Link>
        <nav className="hidden items-center gap-6 font-body text-sm md:flex">
          <Link href="/exam">Practice</Link>
          <Link href="/pricing">Pricing</Link>
          <Link href="/reviews">Reviews</Link>
          <Link href="/contact">Contact</Link>
        </nav>
        <div className="flex items-center gap-3">
          {user ? (
            <Link href="/dashboard" className="btn-secondary !px-4 !py-2 text-sm">
              Dashboard
            </Link>
          ) : (
            <>
              <Link href="/signin" className="hidden text-sm font-body sm:inline">Sign in</Link>
              <Link href="/signup" className="btn-primary !px-4 !py-2 text-sm">Start free trial</Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
