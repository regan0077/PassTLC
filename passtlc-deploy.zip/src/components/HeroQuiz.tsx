"use client";

import { useState } from "react";

type Q = {
  id: string;
  prompt: string;
  choices: string[];
  answer: number;
  explanation?: string | null;
};

export default function HeroQuiz({ question }: { question: Q }) {
  const [selected, setSelected] = useState<number | null>(null);

  const isCorrect = selected !== null && selected === question.answer;

  return (
    <div className="card-flat w-full p-6">
      <div className="font-body text-xs font-bold uppercase tracking-wide text-slate">
        Try a real practice question
      </div>
      <p className="mt-3 font-display text-lg font-bold leading-snug">
        {question.prompt}
      </p>
      <div className="mt-4 space-y-2">
        {question.choices.map((choice, i) => {
          const chosen = selected === i;
          const showState = selected !== null;
          const isRight = i === question.answer;
          return (
            <button
              key={i}
              onClick={() => setSelected(i)}
              disabled={selected !== null}
              className={[
                "w-full rounded-sm border px-4 py-2 text-left font-body text-sm transition-colors",
                showState && isRight
                  ? "border-signal bg-signal/10"
                  : showState && chosen && !isRight
                  ? "border-alert bg-alert/10"
                  : "border-[#d7dbd9] hover:border-ink",
              ].join(" ")}
            >
              {choice}
            </button>
          );
        })}
      </div>
      {selected !== null && (
        <p className="mt-3 font-body text-sm text-slate">
          {isCorrect ? "Correct. " : "Not quite. "}
          {question.explanation}
        </p>
      )}
      {selected !== null && (
        <a href="/signup" className="btn-primary mt-4 !py-2 !px-4 text-sm">
          Get 49 more free questions
        </a>
      )}
    </div>
  );
}
