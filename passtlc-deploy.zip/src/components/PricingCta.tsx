"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function PricingCta() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function subscribe() {
    setLoading(true);
    setError(null);
    const res = await fetch("/api/checkout", { method: "POST" });
    const data = await res.json().catch(() => ({}));
    setLoading(false);

    if (res.status === 401) {
      router.push("/signup?next=/pricing");
      return;
    }
    if (!res.ok) {
      setError(data.error || "Unable to start checkout");
      return;
    }
    window.location.href = data.url;
  }

  return (
    <div>
      <button onClick={subscribe} disabled={loading} className="btn-primary mt-4 w-full">
        {loading ? "Redirecting…" : "Subscribe for $20/month"}
      </button>
      {error && <p className="mt-2 font-body text-sm text-alert">{error}</p>}
    </div>
  );
}
