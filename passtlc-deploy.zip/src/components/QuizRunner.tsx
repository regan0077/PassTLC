"use client";

import { useState } from "react";
import Link from "next/link";

type Q = {
  id: string;
  prompt: string;
  choices: string[];
  answer: number;
  explanation?: string | null;
};

export default function QuizRunner({
  questions,
  signedIn,
  hasFullAccess,
  remainingTrial,
}: {
  questions: Q[];
  signedIn: boolean;
  hasFullAccess: boolean;
  remainingTrial: number;
}) {
  const [index, setIndex] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [trialBlocked, setTrialBlocked] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  if (questions.length === 0) {
    return <p className="mt-8 font-body text-slate">No questions in this category yet.</p>;
  }

  if (!signedIn) {
    return (
      <div className="card-flat mt-8 max-w-md p-6">
        <p className="font-body">Sign in or create a free account to start practicing.</p>
        <Link href="/signup" className="btn-primary mt-4 inline-block">Start free trial</Link>
      </div>
    );
  }

  if (trialBlocked || (!hasFullAccess && remainingTrial <= 0 && selected === null)) {
    return (
      <div className="card-flat mt-8 max-w-md p-6">
        <p className="font-body font-bold">You've used all 50 free trial questions.</p>
        <p className="mt-1 font-body text-sm text-slate">
          Subscribe for $20/month to keep practicing with unlimited questions.
        </p>
        <Link href="/pricing" className="btn-primary mt-4 inline-block">See pricing</Link>
      </div>
    );
  }

  const q = questions[index % questions.length];

  async function submitAnswer(choiceIndex: number) {
    if (selected !== null || submitting) return;
    setSubmitting(true);
    setSelected(choiceIndex);

    const res = await fetch("/api/attempt", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ questionId: q.id, selectedIndex: choiceIndex }),
    });

    if (res.status === 402) {
      setTrialBlocked(true);
      setSubmitting(false);
      return;
    }

    const data = await res.json().catch(() => ({}));
    if (data.correct) setScore((s) => s + 1);
    setSubmitting(false);
  }

  function next() {
    setSelected(null);
    setIndex((i) => i + 1);
  }

  return (
    <div className="mt-8 max-w-xl">
      <div className="font-body text-sm text-slate">
        Question {(index % questions.length) + 1} of {questions.length} · Score {score}
        {!hasFullAccess && ` · ${remainingTrial} free trial questions left`}
      </div>
      <div className="card-flat mt-3 p-6">
        <p className="font-display text-lg font-bold leading-snug">{q.prompt}</p>
        <div className="mt-4 space-y-2">
          {q.choices.map((choice, i) => {
            const showState = selected !== null;
            const isRight = i === q.answer;
            const chosen = selected === i;
            return (
              <button
                key={i}
                onClick={() => submitAnswer(i)}
                disabled={selected !== null}
                className={[
                  "w-full rounded-sm border px-4 py-2 text-left font-body text-sm transition-colors",
                  showState && isRight
                    ? "border-signal bg-signal/10"
                    : showState && chosen && !isRight
                    ? "border-alert bg-alert/10"
                    : "border-[#d7dbd9] hover:border-ink",
                ].join(" ")}
              >
                {choice}
              </button>
            );
          })}
        </div>
        {selected !== null && q.explanation && (
          <p className="mt-3 font-body text-sm text-slate">{q.explanation}</p>
        )}
        {selected !== null && (
          <button onClick={next} className="btn-primary mt-4">Next question</button>
        )}
      </div>
    </div>
  );
}
