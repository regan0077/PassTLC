"use client";

import { useState } from "react";

export default function ReviewForm() {
  const [name, setName] = useState("");
  const [body, setBody] = useState("");
  const [rating, setRating] = useState(5);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const res = await fetch("/api/reviews", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, body, rating }),
    });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error || "Something went wrong");
      return;
    }
    setSubmitted(true);
  }

  if (submitted) {
    return <p className="mt-4 font-body text-signal">Thanks — your review is awaiting approval.</p>;
  }

  return (
    <form onSubmit={onSubmit} className="mt-4 space-y-3">
      <input
        required
        placeholder="Your name"
        value={name}
        onChange={(e) => setName(e.target.value)}
        className="w-full rounded-sm border border-[#d7dbd9] px-3 py-2 font-body text-sm"
      />
      <textarea
        required
        placeholder="Your review"
        value={body}
        onChange={(e) => setBody(e.target.value)}
        rows={3}
        className="w-full rounded-sm border border-[#d7dbd9] px-3 py-2 font-body text-sm"
      />
      <select
        value={rating}
        onChange={(e) => setRating(Number(e.target.value))}
        className="w-full rounded-sm border border-[#d7dbd9] px-3 py-2 font-body text-sm"
      >
        {[5, 4, 3, 2, 1].map((n) => (
          <option key={n} value={n}>{n} stars</option>
        ))}
      </select>
      {error && <p className="font-body text-sm text-alert">{error}</p>}
      <button type="submit" className="btn-primary">Submit review</button>
    </form>
  );
}
