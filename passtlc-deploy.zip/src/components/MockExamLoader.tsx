"use client";

import { useEffect, useState } from "react";
import QuizRunner from "./QuizRunner";

type Q = {
  id: string;
  prompt: string;
  choices: string[];
  answer: number;
  explanation?: string | null;
};

export default function MockExamLoader(props: {
  signedIn: boolean;
  hasFullAccess: boolean;
  remainingTrial: number;
}) {
  const [questions, setQuestions] = useState<Q[] | null>(null);

  useEffect(() => {
    if (!props.signedIn) return;
    fetch("/api/questions?mode=exam")
      .then((r) => r.json())
      .then((d) => setQuestions(d.questions || []));
  }, [props.signedIn]);

  if (!props.signedIn) {
    return <QuizRunner questions={[]} {...props} />;
  }

  if (!questions) {
    return <p className="mt-8 font-body text-slate">Loading exam…</p>;
  }

  return <QuizRunner questions={questions} {...props} />;
}
