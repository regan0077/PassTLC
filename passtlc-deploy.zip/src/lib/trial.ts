// Free-trial policy: anonymous browsing of category pages is unlimited,
// but answering questions counts against a 50-question lifetime trial cap
// per account until the account has an ACTIVE subscription.
export const FREE_TRIAL_QUESTION_LIMIT = 50;

export function hasFullAccess(user: { subscriptionStatus: string } | null | undefined) {
  return user?.subscriptionStatus === "ACTIVE";
}

export function remainingTrialQuestions(user: { questionsAnswered: number } | null | undefined) {
  if (!user) return FREE_TRIAL_QUESTION_LIMIT;
  return Math.max(0, FREE_TRIAL_QUESTION_LIMIT - user.questionsAnswered);
}

export function canAnswerAnotherQuestion(user: {
  questionsAnswered: number;
  subscriptionStatus: string;
}) {
  return hasFullAccess(user) || remainingTrialQuestions(user) > 0;
}
