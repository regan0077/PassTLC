import Database from "better-sqlite3";
import fs from "fs";
import path from "path";

const dbPath = process.env.DATABASE_FILE || path.join(process.cwd(), "data", "passtlc.db");
fs.mkdirSync(path.dirname(dbPath), { recursive: true });

const globalForDb = globalThis as unknown as { __passtlcDb?: Database.Database };

function init() {
  const database = new Database(dbPath);
  database.pragma("journal_mode = WAL");
  database.pragma("foreign_keys = ON");
  const schema = fs.readFileSync(path.join(process.cwd(), "src", "lib", "schema.sql"), "utf-8");
  database.exec(schema);
  return database;
}

export const db = globalForDb.__passtlcDb ?? init();

if (process.env.NODE_ENV !== "production") globalForDb.__passtlcDb = db;
