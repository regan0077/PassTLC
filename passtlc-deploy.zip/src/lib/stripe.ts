import Stripe from "stripe";

let _stripe: Stripe | null = null;

// Lazily constructed so the app can build/run without real Stripe keys set
// (checkout/webhook routes will return a clear config error until keys are added).
export function getStripe(): Stripe {
  if (!process.env.STRIPE_SECRET_KEY) {
    throw new Error("STRIPE_SECRET_KEY is not configured");
  }
  if (!_stripe) {
    _stripe = new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion: "2024-06-20" });
  }
  return _stripe;
}
