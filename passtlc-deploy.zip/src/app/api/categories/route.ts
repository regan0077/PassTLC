import { NextResponse } from "next/server";
import { listCategories } from "@/lib/repo";

export async function GET() {
  return NextResponse.json({ categories: listCategories() });
}
