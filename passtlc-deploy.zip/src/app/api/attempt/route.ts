import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { getQuestionById, createAttempt, incrementQuestionsAnswered } from "@/lib/repo";
import { getCurrentUser } from "@/lib/auth";
import { canAnswerAnotherQuestion, hasFullAccess } from "@/lib/trial";

const schema = z.object({
  questionId: z.string(),
  selectedIndex: z.number().int().min(0),
});

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Sign in to track your progress" }, { status: 401 });
  }

  if (!canAnswerAnotherQuestion(user)) {
    return NextResponse.json(
      { error: "Free trial limit reached", trialExpired: true },
      { status: 402 }
    );
  }

  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid input" }, { status: 400 });
  }

  const question = getQuestionById(parsed.data.questionId);
  if (!question) {
    return NextResponse.json({ error: "Question not found" }, { status: 404 });
  }

  const correct = question.answer === parsed.data.selectedIndex;

  createAttempt(user.id, question.id, correct);
  if (!hasFullAccess(user)) {
    incrementQuestionsAnswered(user.id);
  }

  return NextResponse.json({ correct, correctIndex: question.answer, explanation: question.explanation });
}
