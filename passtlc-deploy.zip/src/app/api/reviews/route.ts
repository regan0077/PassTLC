import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { listApprovedReviews, createReview } from "@/lib/repo";
import { getCurrentUser } from "@/lib/auth";

export async function GET() {
  return NextResponse.json({ reviews: listApprovedReviews() });
}

const schema = z.object({
  name: z.string().min(1).max(60),
  body: z.string().min(5).max(1000),
  rating: z.number().int().min(1).max(5),
});

export async function POST(req: NextRequest) {
  const user = await getCurrentUser();
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid input" }, { status: 400 });
  }

  const review = createReview({
    userId: user?.id ?? null,
    name: parsed.data.name,
    body: parsed.data.body,
    rating: parsed.data.rating,
  });

  return NextResponse.json({ review });
}
