import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import {
  getCategoryBySlug,
  listQuestionsByCategoryId,
  listRandomQuestions,
  createQuestion,
} from "@/lib/repo";
import { requireAdmin } from "@/lib/auth";

export async function GET(req: NextRequest) {
  const categorySlug = req.nextUrl.searchParams.get("category");
  const mode = req.nextUrl.searchParams.get("mode"); // "exam" mixes categories

  if (mode === "exam") {
    const shuffled = listRandomQuestions(20);
    return NextResponse.json({ questions: shuffled.map(withParsedChoices) });
  }

  if (!categorySlug) {
    return NextResponse.json({ error: "category is required" }, { status: 400 });
  }

  const category = getCategoryBySlug(categorySlug);
  if (!category) {
    return NextResponse.json({ error: "Category not found" }, { status: 404 });
  }

  const questions = listQuestionsByCategoryId(category.id);
  return NextResponse.json({ category, questions: questions.map(withParsedChoices) });
}

function withParsedChoices(q: { choices: string; [k: string]: unknown }) {
  return { ...q, choices: JSON.parse(q.choices) };
}

const createSchema = z.object({
  categoryId: z.string(),
  prompt: z.string().min(3),
  choices: z.array(z.string().min(1)).min(2),
  answer: z.number().int().min(0),
  explanation: z.string().optional(),
});

export async function POST(req: NextRequest) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const body = await req.json().catch(() => null);
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message }, { status: 400 });
  }

  const question = createQuestion(parsed.data);
  return NextResponse.json({ question });
}
