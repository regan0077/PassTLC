import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { updateQuestion, deleteQuestion } from "@/lib/repo";
import { requireAdmin } from "@/lib/auth";

const updateSchema = z.object({
  prompt: z.string().min(3).optional(),
  choices: z.array(z.string().min(1)).min(2).optional(),
  answer: z.number().int().min(0).optional(),
  explanation: z.string().optional(),
});

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const body = await req.json().catch(() => null);
  const parsed = updateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message }, { status: 400 });
  }

  const question = updateQuestion(params.id, parsed.data);
  return NextResponse.json({ question });
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }
  deleteQuestion(params.id);
  return NextResponse.json({ ok: true });
}
