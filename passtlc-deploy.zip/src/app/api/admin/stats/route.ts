import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
import {
  countUsers,
  countActiveSubscribers,
  countQuestions,
  countPendingReviews,
  countPendingComments,
} from "@/lib/repo";

export async function GET() {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const activeSubscribers = countActiveSubscribers();

  return NextResponse.json({
    userCount: countUsers(),
    activeSubscribers,
    monthlyRevenueEstimate: activeSubscribers * 20,
    questionCount: countQuestions(),
    pendingReviews: countPendingReviews(),
    pendingComments: countPendingComments(),
  });
}
