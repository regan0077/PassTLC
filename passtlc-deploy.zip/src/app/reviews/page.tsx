import type { Metadata } from "next";
import { listApprovedReviews } from "@/lib/repo";
import ReviewForm from "@/components/ReviewForm";

export const metadata: Metadata = {
  title: "Reviews",
  description: "What drivers say about practicing for the NYC TLC exam with PassTLC.",
};

export default async function ReviewsPage() {
  const reviews = listApprovedReviews();

  return (
    <div className="container-page py-12">
      <h1 className="font-display text-3xl font-bold">Reviews</h1>
      <div className="mt-6 grid gap-4 md:grid-cols-2">
        {reviews.map((r) => (
          <div key={r.id} className="card-flat p-5">
            <div className="font-bold">{r.name}</div>
            <div className="font-body text-sm text-slate">{"★".repeat(r.rating)}</div>
            <p className="mt-2 font-body text-sm">{r.body}</p>
          </div>
        ))}
      </div>

      <div className="mt-10 max-w-md">
        <h2 className="font-display text-xl font-bold">Leave a review</h2>
        <p className="font-body text-sm text-slate">
          Reviews are checked before they're published.
        </p>
        <ReviewForm />
      </div>
    </div>
  );
}
