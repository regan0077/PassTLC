import type { Metadata } from "next";
import SigninForm from "@/components/SigninForm";

export const metadata: Metadata = {
  title: "Sign in",
  description: "Sign in to your PassTLC account.",
};

export default function SigninPage() {
  return (
    <div className="container-page flex min-h-[70vh] items-center justify-center py-16">
      <div className="card-flat w-full max-w-md p-8">
        <h1 className="font-display text-2xl font-bold">Sign in</h1>
        <SigninForm />
      </div>
    </div>
  );
}
