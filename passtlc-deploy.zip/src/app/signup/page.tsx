import type { Metadata } from "next";
import SignupForm from "@/components/SignupForm";

export const metadata: Metadata = {
  title: "Start your free trial",
  description: "Create a free PassTLC account and get 50 free TLC exam practice questions.",
};

export default function SignupPage() {
  return (
    <div className="container-page flex min-h-[70vh] items-center justify-center py-16">
      <div className="card-flat w-full max-w-md p-8">
        <h1 className="font-display text-2xl font-bold">Start your free trial</h1>
        <p className="mt-1 font-body text-sm text-slate">
          50 free questions, no credit card required.
        </p>
        <SignupForm />
      </div>
    </div>
  );
}
