import {
  countUsers,
  countActiveSubscribers,
  countQuestions,
  countPendingReviews,
  countPendingComments,
} from "@/lib/repo";

export default async function AdminOverviewPage() {
  const activeSubscribers = countActiveSubscribers();

  const stats = [
    { label: "Total users", value: countUsers() },
    { label: "Active subscribers", value: activeSubscribers },
    { label: "Est. monthly revenue", value: `$${activeSubscribers * 20}` },
    { label: "Questions in bank", value: countQuestions() },
    { label: "Pending reviews", value: countPendingReviews() },
    { label: "Pending comments", value: countPendingComments() },
  ];

  return (
    <div>
      <h1 className="font-display text-2xl font-bold">Overview</h1>
      <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {stats.map((s) => (
          <div key={s.label} className="card-flat p-4">
            <div className="font-body text-sm text-slate">{s.label}</div>
            <div className="font-display text-2xl font-bold">{s.value}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
