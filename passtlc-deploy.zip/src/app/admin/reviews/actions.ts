"use server";

import { revalidatePath } from "next/cache";
import {
  approveReview as repoApproveReview,
  deleteReview as repoDeleteReview,
  approveComment as repoApproveComment,
  deleteComment as repoDeleteComment,
} from "@/lib/repo";
import { requireAdmin } from "@/lib/auth";

export async function approveReview(id: string) {
  await requireAdmin();
  repoApproveReview(id);
  revalidatePath("/admin/reviews");
}

export async function deleteReview(id: string) {
  await requireAdmin();
  repoDeleteReview(id);
  revalidatePath("/admin/reviews");
}

export async function approveComment(id: string) {
  await requireAdmin();
  repoApproveComment(id);
  revalidatePath("/admin/reviews");
}

export async function deleteComment(id: string) {
  await requireAdmin();
  repoDeleteComment(id);
  revalidatePath("/admin/reviews");
}
