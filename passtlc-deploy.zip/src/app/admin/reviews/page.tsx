import { listPendingReviews, listPendingCommentsWithQuestion } from "@/lib/repo";
import { approveReview, deleteReview, approveComment, deleteComment } from "./actions";

export default async function AdminReviewsPage() {
  const pendingReviews = listPendingReviews();
  const pendingComments = listPendingCommentsWithQuestion();

  return (
    <div>
      <h1 className="font-display text-2xl font-bold">Moderation</h1>

      <h2 className="mt-6 font-display text-lg font-bold">Pending reviews</h2>
      <div className="mt-3 space-y-3">
        {pendingReviews.length === 0 && <p className="font-body text-sm text-slate">Nothing pending.</p>}
        {pendingReviews.map((r) => (
          <div key={r.id} className="card-flat flex items-start justify-between gap-4 p-4">
            <div>
              <div className="font-bold">{r.name} · {r.rating}★</div>
              <p className="font-body text-sm text-slate">{r.body}</p>
            </div>
            <div className="flex gap-3 font-body text-sm font-bold">
              <form action={approveReview.bind(null, r.id)}><button type="submit" className="text-signal">Approve</button></form>
              <form action={deleteReview.bind(null, r.id)}><button type="submit" className="text-alert">Delete</button></form>
            </div>
          </div>
        ))}
      </div>

      <h2 className="mt-10 font-display text-lg font-bold">Pending comments</h2>
      <div className="mt-3 space-y-3">
        {pendingComments.length === 0 && <p className="font-body text-sm text-slate">Nothing pending.</p>}
        {pendingComments.map((c) => (
          <div key={c.id} className="card-flat flex items-start justify-between gap-4 p-4">
            <div>
              <div className="font-bold">{c.name} on "{c.questionPrompt.slice(0, 40)}…"</div>
              <p className="font-body text-sm text-slate">{c.body}</p>
            </div>
            <div className="flex gap-3 font-body text-sm font-bold">
              <form action={approveComment.bind(null, c.id)}><button type="submit" className="text-signal">Approve</button></form>
              <form action={deleteComment.bind(null, c.id)}><button type="submit" className="text-alert">Delete</button></form>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
