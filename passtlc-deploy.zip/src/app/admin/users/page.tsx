import { listUsers } from "@/lib/repo";
import { toggleSubscription } from "./actions";

export default async function AdminUsersPage() {
  const users = listUsers(200);

  return (
    <div>
      <h1 className="font-display text-2xl font-bold">Users</h1>
      <div className="mt-6 overflow-x-auto">
        <table className="w-full font-body text-sm">
          <thead>
            <tr className="border-b border-[#d7dbd9] text-left">
              <th className="py-2">Email</th>
              <th>Role</th>
              <th>Trial used</th>
              <th>Subscription</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id} className="border-b border-[#d7dbd9]">
                <td className="py-2">{u.email}</td>
                <td>{u.role}</td>
                <td>{u.questionsAnswered}/50</td>
                <td>{u.subscriptionStatus}</td>
                <td>
                  <form action={toggleSubscription.bind(null, u.id, u.subscriptionStatus)}>
                    <button className="font-bold underline" type="submit">
                      {u.subscriptionStatus === "ACTIVE" ? "Revoke access" : "Grant access"}
                    </button>
                  </form>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
