"use server";

import { revalidatePath } from "next/cache";
import { setUserSubscriptionStatus } from "@/lib/repo";
import { requireAdmin } from "@/lib/auth";

export async function toggleSubscription(userId: string, currentStatus: string) {
  await requireAdmin();
  const next = currentStatus === "ACTIVE" ? "NONE" : "ACTIVE";
  setUserSubscriptionStatus(userId, next);
  revalidatePath("/admin/users");
}
