import { listCategories } from "@/lib/repo";
import { createCategory, deleteCategory } from "./actions";

export default async function AdminCategoriesPage() {
  const categories = listCategories();

  return (
    <div>
      <h1 className="font-display text-2xl font-bold">Categories</h1>

      <div className="mt-6 space-y-3">
        {categories.map((c) => (
          <div key={c.id} className="card-flat flex items-center justify-between p-4">
            <div>
              <div className="font-bold">{c.name}</div>
              <div className="font-body text-sm text-slate">
                /{c.slug} · {c.questionCount} questions
              </div>
            </div>
            <form action={deleteCategory.bind(null, c.id)}>
              <button className="font-body text-sm font-bold text-alert" type="submit">Delete</button>
            </form>
          </div>
        ))}
      </div>

      <h2 className="mt-10 font-display text-lg font-bold">Add category</h2>
      <form action={createCategory} className="mt-4 max-w-md space-y-3 font-body text-sm">
        <input name="name" placeholder="Name" required className="w-full rounded-sm border border-[#d7dbd9] px-3 py-2" />
        <input name="slug" placeholder="url-slug" required className="w-full rounded-sm border border-[#d7dbd9] px-3 py-2" />
        <textarea name="summary" placeholder="Short summary" rows={2} className="w-full rounded-sm border border-[#d7dbd9] px-3 py-2" />
        <button type="submit" className="btn-primary">Add category</button>
      </form>
    </div>
  );
}
