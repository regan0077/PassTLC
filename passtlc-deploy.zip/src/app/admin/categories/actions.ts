"use server";

import { revalidatePath } from "next/cache";
import { createCategory as repoCreateCategory, deleteCategory as repoDeleteCategory } from "@/lib/repo";
import { requireAdmin } from "@/lib/auth";

export async function createCategory(formData: FormData) {
  await requireAdmin();
  const name = String(formData.get("name"));
  const slug = String(formData.get("slug"));
  const summary = String(formData.get("summary") || "");

  repoCreateCategory(name, slug, summary);
  revalidatePath("/admin/categories");
}

export async function deleteCategory(id: string) {
  await requireAdmin();
  repoDeleteCategory(id);
  revalidatePath("/admin/categories");
}
