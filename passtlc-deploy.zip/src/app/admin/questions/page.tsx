import { listQuestionsWithCategory } from "@/lib/repo";
import { deleteQuestion } from "./actions";

export default async function AdminQuestionsPage() {
  const questions = listQuestionsWithCategory(100);

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-bold">Questions</h1>
        <a href="/admin/questions/new" className="btn-primary !px-4 !py-2 text-sm">
          Add question
        </a>
      </div>
      <div className="mt-6 space-y-3">
        {questions.map((q) => (
          <div key={q.id} className="card-flat flex items-start justify-between gap-4 p-4">
            <div>
              <div className="font-body text-xs font-bold uppercase text-slate">
                {q.categoryName}
              </div>
              <div className="mt-1 font-body text-sm">{q.prompt}</div>
            </div>
            <form action={deleteQuestion.bind(null, q.id)}>
              <button className="font-body text-sm font-bold text-alert" type="submit">
                Delete
              </button>
            </form>
          </div>
        ))}
      </div>
    </div>
  );
}
