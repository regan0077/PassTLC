import { listCategories } from "@/lib/repo";
import { createQuestion } from "../actions";

export default async function NewQuestionPage() {
  const categories = listCategories();

  return (
    <div>
      <h1 className="font-display text-2xl font-bold">Add question</h1>
      <form action={createQuestion} className="mt-6 max-w-lg space-y-4 font-body text-sm">
        <div>
          <label className="font-bold">Category</label>
          <select name="categoryId" required className="mt-1 w-full rounded-sm border border-[#d7dbd9] px-3 py-2">
            {categories.map((c) => (
              <option key={c.id} value={c.id}>{c.name}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="font-bold">Prompt</label>
          <textarea name="prompt" required rows={2} className="mt-1 w-full rounded-sm border border-[#d7dbd9] px-3 py-2" />
        </div>
        {[0, 1, 2, 3].map((i) => (
          <div key={i}>
            <label className="font-bold">Choice {i + 1}</label>
            <input
              name={`choice${i}`}
              required={i < 2}
              className="mt-1 w-full rounded-sm border border-[#d7dbd9] px-3 py-2"
            />
          </div>
        ))}
        <div>
          <label className="font-bold">Correct choice index (0-3)</label>
          <input name="answer" type="number" min={0} max={3} required className="mt-1 w-full rounded-sm border border-[#d7dbd9] px-3 py-2" />
        </div>
        <div>
          <label className="font-bold">Explanation</label>
          <textarea name="explanation" rows={2} className="mt-1 w-full rounded-sm border border-[#d7dbd9] px-3 py-2" />
        </div>
        <button type="submit" className="btn-primary">Save question</button>
      </form>
    </div>
  );
}
