"use server";

import { revalidatePath } from "next/cache";
import { createQuestion as repoCreateQuestion, deleteQuestion as repoDeleteQuestion } from "@/lib/repo";
import { requireAdmin } from "@/lib/auth";

export async function deleteQuestion(id: string) {
  await requireAdmin();
  repoDeleteQuestion(id);
  revalidatePath("/admin/questions");
}

export async function createQuestion(formData: FormData) {
  await requireAdmin();
  const categoryId = String(formData.get("categoryId"));
  const prompt = String(formData.get("prompt"));
  const explanation = String(formData.get("explanation") || "");
  const answer = Number(formData.get("answer"));
  const choices = [
    String(formData.get("choice0") || ""),
    String(formData.get("choice1") || ""),
    String(formData.get("choice2") || ""),
    String(formData.get("choice3") || ""),
  ].filter((c) => c.trim().length > 0);

  repoCreateQuestion({ categoryId, prompt, choices, answer, explanation });

  revalidatePath("/admin/questions");
}
