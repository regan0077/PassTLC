import type { Metadata } from "next";
import { requireUser } from "@/lib/auth";
import { attemptStatsByCategoryForUser } from "@/lib/repo";
import { hasFullAccess, remainingTrialQuestions } from "@/lib/trial";
import SignOutButton from "@/components/SignOutButton";
import PricingCta from "@/components/PricingCta";

export const metadata: Metadata = { title: "Dashboard" };

export default async function DashboardPage() {
  const user = await requireUser();
  const stats = attemptStatsByCategoryForUser(user.id);
  const fullAccess = hasFullAccess(user);

  return (
    <div className="container-page py-12">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-3xl font-bold">Your dashboard</h1>
        <SignOutButton />
      </div>
      <p className="mt-1 font-body text-slate">{user.email}</p>

      {!fullAccess && (
        <div className="card-flat mt-6 max-w-md p-5">
          <p className="font-body font-bold">
            {remainingTrialQuestions(user)} free trial questions remaining
          </p>
          <PricingCta />
        </div>
      )}

      <h2 className="mt-10 font-display text-xl font-bold">Progress by category</h2>
      {stats.length === 0 ? (
        <p className="mt-2 font-body text-slate">
          You haven't answered any questions yet. Head to Practice to get started.
        </p>
      ) : (
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          {stats.map((s) => (
            <div key={s.categoryName} className="card-flat p-4">
              <div className="font-bold">{s.categoryName}</div>
              <div className="font-body text-sm text-slate">
                {s.correct} / {s.total} correct
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
