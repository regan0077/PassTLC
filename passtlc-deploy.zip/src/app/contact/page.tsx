import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Contact",
  description: "Get in touch with the PassTLC team.",
};

export default function ContactPage() {
  return (
    <div className="container-page py-12">
      <h1 className="font-display text-3xl font-bold">Contact us</h1>
      <p className="mt-2 max-w-prose font-body text-slate">
        Found an error in a question, or have feedback? Email{" "}
        <a className="font-bold underline" href="mailto:support@passtlc.com">
          support@passtlc.com
        </a>{" "}
        and we'll take a look.
      </p>
    </div>
  );
}
