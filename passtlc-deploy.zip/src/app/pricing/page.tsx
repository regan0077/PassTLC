import type { Metadata } from "next";
import PricingCta from "@/components/PricingCta";

export const metadata: Metadata = {
  title: "Pricing",
  description: "PassTLC pricing: 50 free practice questions, then $20/month for unlimited access.",
};

const freeFeatures = [
  "50 practice questions total",
  "All 7 exam categories",
  "Instant answer explanations",
];

const paidFeatures = [
  "Unlimited practice questions",
  "Full mock exams",
  "Progress tracking by category",
  "Priority support",
];

export default function PricingPage() {
  return (
    <div className="container-page py-14">
      <h1 className="font-display text-3xl font-bold">Simple pricing</h1>
      <p className="mt-2 max-w-prose font-body text-slate">
        Try it free. Upgrade when you're ready for unlimited practice.
      </p>

      <div className="mt-8 grid gap-6 md:grid-cols-2 md:max-w-2xl">
        <div className="card-flat p-6">
          <div className="font-display text-xl font-bold">Free trial</div>
          <div className="mt-1 font-display text-3xl font-bold">$0</div>
          <ul className="mt-4 space-y-2 font-body text-sm text-slate">
            {freeFeatures.map((f) => (
              <li key={f}>· {f}</li>
            ))}
          </ul>
        </div>

        <div className="card-flat border-2 border-ink p-6">
          <div className="font-display text-xl font-bold">Full access</div>
          <div className="mt-1 font-display text-3xl font-bold">
            $20<span className="text-base font-normal text-slate">/month</span>
          </div>
          <ul className="mt-4 space-y-2 font-body text-sm text-slate">
            {paidFeatures.map((f) => (
              <li key={f}>· {f}</li>
            ))}
          </ul>
          <PricingCta />
        </div>
      </div>
    </div>
  );
}
