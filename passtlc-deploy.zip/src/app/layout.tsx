import type { Metadata } from "next";
import "./globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://passtlc.com";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "PassTLC — NYC TLC License Exam Practice Questions",
    template: "%s | PassTLC",
  },
  description:
    "Practice for the NYC TLC license exam with categorized questions, instant feedback, and full-length mock exams. Free trial, then $20/month for unlimited access.",
  keywords: [
    "NYC TLC exam",
    "TLC license practice test",
    "TLC exam questions",
    "taxi and limousine commission exam",
    "pass TLC exam",
  ],
  openGraph: {
    title: "PassTLC — NYC TLC License Exam Practice Questions",
    description:
      "Categorized practice questions and mock exams to help you pass the NYC TLC license exam.",
    url: siteUrl,
    siteName: "PassTLC",
    type: "website",
  },
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="font-body">
        <Navbar />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  );
}
