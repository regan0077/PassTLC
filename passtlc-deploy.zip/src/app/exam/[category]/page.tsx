import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { getCategoryBySlug, listQuestionsByCategoryId } from "@/lib/repo";
import { getCurrentUser } from "@/lib/auth";
import { remainingTrialQuestions, hasFullAccess } from "@/lib/trial";
import QuizRunner from "@/components/QuizRunner";

export async function generateMetadata({
  params,
}: {
  params: { category: string };
}): Promise<Metadata> {
  const category = getCategoryBySlug(params.category);
  if (!category) return {};
  return {
    title: `${category.name} practice questions`,
    description: `Practice ${category.name} questions for the NYC TLC license exam. ${category.summary}`,
  };
}

export default async function CategoryExamPage({ params }: { params: { category: string } }) {
  const category = getCategoryBySlug(params.category);
  if (!category) notFound();

  const questions = listQuestionsByCategoryId(category.id);
  const user = await getCurrentUser();

  return (
    <div className="container-page py-12">
      <h1 className="font-display text-3xl font-bold">{category.name}</h1>
      <p className="mt-2 max-w-prose font-body text-slate">{category.summary}</p>

      <QuizRunner
        questions={questions.map((q) => ({
          id: q.id,
          prompt: q.prompt,
          choices: JSON.parse(q.choices),
          answer: q.answer,
          explanation: q.explanation,
        }))}
        signedIn={!!user}
        hasFullAccess={user ? hasFullAccess(user) : false}
        remainingTrial={user ? remainingTrialQuestions(user) : 50}
      />
    </div>
  );
}
