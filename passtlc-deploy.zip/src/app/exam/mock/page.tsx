import type { Metadata } from "next";
import { getCurrentUser } from "@/lib/auth";
import { remainingTrialQuestions, hasFullAccess } from "@/lib/trial";
import MockExamLoader from "@/components/MockExamLoader";

export const metadata: Metadata = {
  title: "Mock exam",
  description: "Take a timed, mixed-category mock TLC license exam.",
};

export default async function MockExamPage() {
  const user = await getCurrentUser();
  return (
    <div className="container-page py-12">
      <h1 className="font-display text-3xl font-bold">Mock exam</h1>
      <p className="mt-2 max-w-prose font-body text-slate">
        20 mixed questions pulled from every category, timed like the real exam.
      </p>
      <MockExamLoader
        signedIn={!!user}
        hasFullAccess={user ? hasFullAccess(user) : false}
        remainingTrial={user ? remainingTrialQuestions(user) : 50}
      />
    </div>
  );
}
