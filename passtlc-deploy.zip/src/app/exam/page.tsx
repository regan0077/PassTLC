import type { Metadata } from "next";
import Link from "next/link";
import { listCategories } from "@/lib/repo";

export const metadata: Metadata = {
  title: "Practice categories",
  description: "Browse all NYC TLC exam practice categories.",
};

export default async function ExamIndexPage() {
  const categories = listCategories();

  return (
    <div className="container-page py-12">
      <h1 className="font-display text-3xl font-bold">Practice categories</h1>
      <p className="mt-2 max-w-prose font-body text-slate">
        Pick a category to practice, or take a mixed mock exam.
      </p>
      <div className="mt-6">
        <Link href="/exam/mock" className="btn-primary">Take a mock exam</Link>
      </div>
      <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {categories.map((c) => (
          <Link key={c.id} href={`/exam/${c.slug}`} className="card-flat flex flex-col justify-between p-5 hover:border-ink">
            <div>
              <div className="font-display text-lg font-bold">{c.name}</div>
              <p className="mt-1 font-body text-sm text-slate">{c.summary}</p>
            </div>
            <div className="mt-4 font-body text-sm font-bold">{c.questionCount} questions →</div>
          </Link>
        ))}
      </div>
    </div>
  );
}
