import Link from "next/link";
import { listCategories, listApprovedReviews, listRandomQuestions } from "@/lib/repo";
import HeroQuiz from "@/components/HeroQuiz";

export default async function HomePage() {
  const categories = listCategories();
  const [sampleQuestion] = listRandomQuestions(1);
  const reviews = listApprovedReviews().slice(0, 3);

  return (
    <div>
      <section className="container-page grid gap-10 py-12 md:grid-cols-2 md:py-20">
        <div className="flex flex-col justify-center">
          <h1 className="font-display text-4xl font-bold leading-tight tracking-tight md:text-5xl">
            Study the NYC TLC exam the way you'll actually take it.
          </h1>
          <p className="mt-4 max-w-prose font-body text-lg text-slate">
            Seven exam categories, instant answer explanations, and full mock
            exams. Start with 50 free questions — no credit card required.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link href="/signup" className="btn-primary">Start free trial</Link>
            <Link href="/exam" className="btn-secondary">Browse categories</Link>
          </div>
          <p className="mt-3 font-body text-sm text-slate">
            50 free practice questions, then $20/month for unlimited access.
          </p>
        </div>
        <div className="flex items-center">
          {sampleQuestion ? (
            <HeroQuiz
              question={{
                id: sampleQuestion.id,
                prompt: sampleQuestion.prompt,
                choices: JSON.parse(sampleQuestion.choices),
                answer: sampleQuestion.answer,
                explanation: sampleQuestion.explanation,
              }}
            />
          ) : null}
        </div>
      </section>

      <section className="border-y border-[#d7dbd9] bg-white py-14">
        <div className="container-page">
          <h2 className="font-display text-2xl font-bold">Practice by category</h2>
          <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {categories.map((c) => (
              <Link
                key={c.id}
                href={`/exam/${c.slug}`}
                className="card-flat flex flex-col justify-between p-5 hover:border-ink"
              >
                <div>
                  <div className="font-display text-lg font-bold">{c.name}</div>
                  <p className="mt-1 font-body text-sm text-slate">{c.summary}</p>
                </div>
                <div className="mt-4 font-body text-sm font-bold">
                  {c.questionCount} questions →
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="container-page py-14">
        <h2 className="font-display text-2xl font-bold">How it works</h2>
        <ol className="mt-6 grid gap-6 md:grid-cols-3">
          <li className="card-flat p-6">
            <div className="font-display text-3xl font-bold text-taxi">1</div>
            <div className="mt-2 font-bold">Practice by category</div>
            <p className="mt-1 font-body text-sm text-slate">
              Work through real exam topics at your own pace, with an
              explanation after every answer.
            </p>
          </li>
          <li className="card-flat p-6">
            <div className="font-display text-3xl font-bold text-taxi">2</div>
            <div className="mt-2 font-bold">Track weak spots</div>
            <p className="mt-1 font-body text-sm text-slate">
              Your dashboard shows which categories need more review before
              exam day.
            </p>
          </li>
          <li className="card-flat p-6">
            <div className="font-display text-3xl font-bold text-taxi">3</div>
            <div className="mt-2 font-bold">Take a mock exam</div>
            <p className="mt-1 font-body text-sm text-slate">
              Simulate the real thing with a timed, mixed-category practice
              exam.
            </p>
          </li>
        </ol>
      </section>

      {reviews.length > 0 && (
        <section className="border-t border-[#d7dbd9] bg-white py-14">
          <div className="container-page">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-2xl font-bold">Reviews</h2>
              <Link href="/reviews" className="font-body text-sm font-bold">
                All reviews
              </Link>
            </div>
            <div className="mt-6 grid gap-4 md:grid-cols-3">
              {reviews.map((r) => (
                <div key={r.id} className="card-flat p-5">
                  <div className="font-bold">{r.name}</div>
                  <p className="mt-2 font-body text-sm text-slate">{r.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}
    </div>
  );
}
