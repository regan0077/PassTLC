import type { MetadataRoute } from "next";
import { listCategories } from "@/lib/repo";

export default function sitemap(): MetadataRoute.Sitemap {
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://passtlc.com";
  const categories = listCategories();

  const staticRoutes = ["", "/exam", "/pricing", "/reviews", "/contact", "/signin", "/signup"].map(
    (path) => ({
      url: `${siteUrl}${path}`,
      lastModified: new Date(),
    })
  );

  const categoryRoutes = categories.map((c) => ({
    url: `${siteUrl}/exam/${c.slug}`,
    lastModified: new Date(),
  }));

  return [...staticRoutes, ...categoryRoutes];
}
