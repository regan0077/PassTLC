"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

const fieldClass =
  "mt-1 w-full rounded-sm border border-[#d7dbd9] bg-white px-3 py-2 font-body text-sm text-ink transition-colors focus:border-ink";

export default function SignupForm() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [zelleAccount, setZelleAccount] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const res = await fetch("/api/auth/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, phone, address, zelleAccount, password }),
    });
    setLoading(false);
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setError(data.error || "Something went wrong");
      return;
    }
    router.push("/dashboard");
    router.refresh();
  }

  return (
    <form onSubmit={onSubmit} className="mt-6 space-y-4" noValidate>
      <div>
        <label className="font-body text-sm font-bold" htmlFor="name">
          Full name
        </label>
        <input
          id="name"
          type="text"
          autoComplete="name"
          required
          value={name}
          onChange={(e) => setName(e.target.value)}
          className={fieldClass}
        />
      </div>

      <div>
        <label className="font-body text-sm font-bold" htmlFor="email">
          Email
        </label>
        <input
          id="email"
          type="email"
          autoComplete="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className={fieldClass}
        />
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label className="font-body text-sm font-bold" htmlFor="phone">
            Phone
          </label>
          <input
            id="phone"
            type="tel"
            autoComplete="tel"
            required
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className={fieldClass}
          />
        </div>
        <div>
          <label className="font-body text-sm font-bold" htmlFor="zelleAccount">
            Zelle account
          </label>
          <input
            id="zelleAccount"
            type="text"
            placeholder="Email or phone used for Zelle"
            required
            value={zelleAccount}
            onChange={(e) => setZelleAccount(e.target.value)}
            className={fieldClass}
          />
        </div>
      </div>

      <div>
        <label className="font-body text-sm font-bold" htmlFor="address">
          Address
        </label>
        <input
          id="address"
          type="text"
          autoComplete="street-address"
          required
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          className={fieldClass}
        />
      </div>

      <div>
        <label className="font-body text-sm font-bold" htmlFor="password">
          Password
        </label>
        <input
          id="password"
          type="password"
          autoComplete="new-password"
          required
          minLength={8}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className={fieldClass}
        />
      </div>

      {error && <p className="font-body text-sm text-alert">{error}</p>}

      <button type="submit" disabled={loading} className="btn-primary w-full disabled:opacity-60">
        {loading ? "Creating account…" : "Create free account"}
      </button>
    </form>
  );
}
