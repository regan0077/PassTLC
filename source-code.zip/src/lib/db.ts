import Database from "better-sqlite3";
import fs from "fs";
import path from "path";

const dbPath = process.env.DATABASE_FILE || path.join(process.cwd(), "data", "passtlc.db");
fs.mkdirSync(path.dirname(dbPath), { recursive: true });

const globalForDb = globalThis as unknown as { __passtlcDb?: Database.Database };

// Columns added after the initial release. CREATE TABLE IF NOT EXISTS (in
// schema.sql) only affects brand-new databases, so existing ones need these
// applied via ALTER TABLE. Safe to run on every startup: each column is only
// added if it's missing.
const USER_COLUMN_MIGRATIONS: { name: string; ddl: string }[] = [
  { name: "name", ddl: "ALTER TABLE users ADD COLUMN name TEXT" },
  { name: "phone", ddl: "ALTER TABLE users ADD COLUMN phone TEXT" },
  { name: "address", ddl: "ALTER TABLE users ADD COLUMN address TEXT" },
  { name: "zelleAccount", ddl: "ALTER TABLE users ADD COLUMN zelleAccount TEXT" },
  {
    name: "accountStatus",
    ddl: "ALTER TABLE users ADD COLUMN accountStatus TEXT NOT NULL DEFAULT 'ACTIVE'",
  },
];

function migrate(database: Database.Database) {
  const existingColumns = new Set(
    (database.prepare("PRAGMA table_info(users)").all() as { name: string }[]).map((c) => c.name)
  );
  for (const { name, ddl } of USER_COLUMN_MIGRATIONS) {
    if (!existingColumns.has(name)) {
      database.exec(ddl);
    }
  }
}

function init() {
  const database = new Database(dbPath);
  database.pragma("journal_mode = WAL");
  database.pragma("foreign_keys = ON");
  const schema = fs.readFileSync(path.join(process.cwd(), "src", "lib", "schema.sql"), "utf-8");
  database.exec(schema);
  migrate(database);
  return database;
}

export const db = globalForDb.__passtlcDb ?? init();

if (process.env.NODE_ENV !== "production") globalForDb.__passtlcDb = db;
