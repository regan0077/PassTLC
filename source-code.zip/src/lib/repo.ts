import { randomUUID } from "crypto";
import { db } from "./db";

// ---------- Types ----------
export type Role = "USER" | "ADMIN";
export type SubscriptionStatus = "NONE" | "ACTIVE" | "CANCELED" | "PAST_DUE";

export type AccountStatus = "ACTIVE" | "DISABLED";

export type UserRow = {
  id: string;
  email: string;
  passwordHash: string;
  role: Role;
  createdAt: string;
  questionsAnswered: number;
  subscriptionStatus: SubscriptionStatus;
  stripeCustomerId: string | null;
  stripeSubscriptionId: string | null;
  currentPeriodEnd: string | null;
  name: string | null;
  phone: string | null;
  address: string | null;
  zelleAccount: string | null;
  accountStatus: AccountStatus;
};

export type CategoryRow = {
  id: string;
  slug: string;
  name: string;
  summary: string;
  sortOrder: number;
};

export type QuestionRow = {
  id: string;
  categoryId: string;
  prompt: string;
  choices: string; // JSON-encoded string[]
  answer: number;
  explanation: string | null;
  createdAt: string;
};

export type ReviewRow = {
  id: string;
  userId: string | null;
  name: string;
  body: string;
  rating: number;
  approved: number;
  createdAt: string;
};

export type CommentRow = {
  id: string;
  questionId: string;
  userId: string | null;
  name: string;
  body: string;
  approved: number;
  createdAt: string;
};

// ---------- Users ----------
export function findUserByEmail(email: string): UserRow | undefined {
  return db.prepare("SELECT * FROM users WHERE email = ?").get(email) as UserRow | undefined;
}

export function findUserById(id: string): UserRow | undefined {
  return db.prepare("SELECT * FROM users WHERE id = ?").get(id) as UserRow | undefined;
}

export function createUser(
  email: string,
  passwordHash: string,
  profile: { name?: string; phone?: string; address?: string; zelleAccount?: string } = {},
  role: Role = "USER"
): UserRow {
  const id = randomUUID();
  const createdAt = new Date().toISOString();
  db.prepare(
    `INSERT INTO users (id, email, passwordHash, role, createdAt, name, phone, address, zelleAccount)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    id,
    email,
    passwordHash,
    role,
    createdAt,
    profile.name ?? null,
    profile.phone ?? null,
    profile.address ?? null,
    profile.zelleAccount ?? null
  );
  return findUserById(id)!;
}

export function upsertAdminUser(email: string, passwordHash: string): UserRow {
  const existing = findUserByEmail(email);
  if (existing) {
    db.prepare(
      "UPDATE users SET role = 'ADMIN', passwordHash = ?, subscriptionStatus = 'ACTIVE' WHERE id = ?"
    ).run(passwordHash, existing.id);
    return findUserById(existing.id)!;
  }
  const id = randomUUID();
  const createdAt = new Date().toISOString();
  db.prepare(
    "INSERT INTO users (id, email, passwordHash, role, createdAt, subscriptionStatus) VALUES (?, ?, ?, 'ADMIN', ?, 'ACTIVE')"
  ).run(id, email, passwordHash, createdAt);
  return findUserById(id)!;
}

export function incrementQuestionsAnswered(userId: string) {
  db.prepare("UPDATE users SET questionsAnswered = questionsAnswered + 1 WHERE id = ?").run(userId);
}

export function setUserStripeCustomer(userId: string, stripeCustomerId: string) {
  db.prepare("UPDATE users SET stripeCustomerId = ? WHERE id = ?").run(stripeCustomerId, userId);
}

export function updateSubscriptionByCustomerId(
  stripeCustomerId: string,
  data: { subscriptionStatus: SubscriptionStatus; stripeSubscriptionId?: string; currentPeriodEnd?: string }
) {
  db.prepare(
    "UPDATE users SET subscriptionStatus = ?, stripeSubscriptionId = COALESCE(?, stripeSubscriptionId), currentPeriodEnd = COALESCE(?, currentPeriodEnd) WHERE stripeCustomerId = ?"
  ).run(data.subscriptionStatus, data.stripeSubscriptionId ?? null, data.currentPeriodEnd ?? null, stripeCustomerId);
}

export function setUserSubscriptionStatus(userId: string, status: SubscriptionStatus) {
  db.prepare("UPDATE users SET subscriptionStatus = ? WHERE id = ?").run(status, userId);
}

export function listUsers(limit = 200): UserRow[] {
  return db.prepare("SELECT * FROM users ORDER BY createdAt DESC LIMIT ?").all(limit) as UserRow[];
}

export function setUserAccountStatus(userId: string, status: AccountStatus) {
  db.prepare("UPDATE users SET accountStatus = ? WHERE id = ?").run(status, userId);
}

export function deleteUser(userId: string) {
  db.prepare("DELETE FROM users WHERE id = ?").run(userId);
}

export function countActiveAccounts(): number {
  return (
    db.prepare("SELECT COUNT(*) as c FROM users WHERE accountStatus = 'ACTIVE'").get() as { c: number }
  ).c;
}

export function countDisabledAccounts(): number {
  return (
    db.prepare("SELECT COUNT(*) as c FROM users WHERE accountStatus = 'DISABLED'").get() as { c: number }
  ).c;
}

export function countUsers(): number {
  return (db.prepare("SELECT COUNT(*) as c FROM users").get() as { c: number }).c;
}

export function countActiveSubscribers(): number {
  return (
    db.prepare("SELECT COUNT(*) as c FROM users WHERE subscriptionStatus = 'ACTIVE'").get() as {
      c: number;
    }
  ).c;
}

// ---------- Categories ----------
export function listCategories(): (CategoryRow & { questionCount: number })[] {
  return db
    .prepare(
      `SELECT c.*, (SELECT COUNT(*) FROM questions q WHERE q.categoryId = c.id) as questionCount
       FROM categories c ORDER BY sortOrder ASC`
    )
    .all() as (CategoryRow & { questionCount: number })[];
}

export function getCategoryBySlug(slug: string): CategoryRow | undefined {
  return db.prepare("SELECT * FROM categories WHERE slug = ?").get(slug) as CategoryRow | undefined;
}

export function getCategoryById(id: string): CategoryRow | undefined {
  return db.prepare("SELECT * FROM categories WHERE id = ?").get(id) as CategoryRow | undefined;
}

export function upsertCategory(slug: string, name: string, summary: string, sortOrder: number): CategoryRow {
  const existing = getCategoryBySlug(slug);
  if (existing) {
    db.prepare("UPDATE categories SET name = ?, summary = ?, sortOrder = ? WHERE id = ?").run(
      name,
      summary,
      sortOrder,
      existing.id
    );
    return getCategoryById(existing.id)!;
  }
  const id = randomUUID();
  db.prepare("INSERT INTO categories (id, slug, name, summary, sortOrder) VALUES (?, ?, ?, ?, ?)").run(
    id,
    slug,
    name,
    summary,
    sortOrder
  );
  return getCategoryById(id)!;
}

export function createCategory(name: string, slug: string, summary: string): CategoryRow {
  const count = (db.prepare("SELECT COUNT(*) as c FROM categories").get() as { c: number }).c;
  return upsertCategory(slug, name, summary, count);
}

export function deleteCategory(id: string) {
  db.prepare("DELETE FROM categories WHERE id = ?").run(id);
}

// ---------- Questions ----------
export function listQuestionsByCategoryId(categoryId: string): QuestionRow[] {
  return db.prepare("SELECT * FROM questions WHERE categoryId = ?").all(categoryId) as QuestionRow[];
}

export function getQuestionById(id: string): QuestionRow | undefined {
  return db.prepare("SELECT * FROM questions WHERE id = ?").get(id) as QuestionRow | undefined;
}

export function findQuestionByPrompt(categoryId: string, prompt: string): QuestionRow | undefined {
  return db
    .prepare("SELECT * FROM questions WHERE categoryId = ? AND prompt = ?")
    .get(categoryId, prompt) as QuestionRow | undefined;
}

export function createQuestion(data: {
  categoryId: string;
  prompt: string;
  choices: string[];
  answer: number;
  explanation?: string | null;
}): QuestionRow {
  const id = randomUUID();
  const createdAt = new Date().toISOString();
  db.prepare(
    "INSERT INTO questions (id, categoryId, prompt, choices, answer, explanation, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?)"
  ).run(id, data.categoryId, data.prompt, JSON.stringify(data.choices), data.answer, data.explanation ?? null, createdAt);
  return getQuestionById(id)!;
}

export function updateQuestion(
  id: string,
  data: Partial<{ prompt: string; choices: string[]; answer: number; explanation: string }>
) {
  const current = getQuestionById(id);
  if (!current) return undefined;
  const prompt = data.prompt ?? current.prompt;
  const choices = data.choices ? JSON.stringify(data.choices) : current.choices;
  const answer = data.answer ?? current.answer;
  const explanation = data.explanation ?? current.explanation;
  db.prepare("UPDATE questions SET prompt = ?, choices = ?, answer = ?, explanation = ? WHERE id = ?").run(
    prompt,
    choices,
    answer,
    explanation,
    id
  );
  return getQuestionById(id);
}

export function deleteQuestion(id: string) {
  db.prepare("DELETE FROM questions WHERE id = ?").run(id);
}

export function countQuestions(): number {
  return (db.prepare("SELECT COUNT(*) as c FROM questions").get() as { c: number }).c;
}

export function listQuestionsWithCategory(limit = 100) {
  return db
    .prepare(
      `SELECT q.*, c.name as categoryName, c.slug as categorySlug
       FROM questions q JOIN categories c ON c.id = q.categoryId
       ORDER BY q.createdAt DESC LIMIT ?`
    )
    .all(limit) as (QuestionRow & { categoryName: string; categorySlug: string })[];
}

export function listRandomQuestions(limit: number): QuestionRow[] {
  return db.prepare("SELECT * FROM questions ORDER BY RANDOM() LIMIT ?").all(limit) as QuestionRow[];
}

// ---------- Attempts ----------
export function createAttempt(userId: string, questionId: string, correct: boolean) {
  const id = randomUUID();
  const createdAt = new Date().toISOString();
  db.prepare("INSERT INTO attempts (id, userId, questionId, correct, createdAt) VALUES (?, ?, ?, ?, ?)").run(
    id,
    userId,
    questionId,
    correct ? 1 : 0,
    createdAt
  );
}

export function attemptStatsByCategoryForUser(userId: string) {
  return db
    .prepare(
      `SELECT c.name as categoryName,
              COUNT(*) as total,
              SUM(a.correct) as correct
       FROM attempts a
       JOIN questions q ON q.id = a.questionId
       JOIN categories c ON c.id = q.categoryId
       WHERE a.userId = ?
       GROUP BY c.name`
    )
    .all(userId) as { categoryName: string; total: number; correct: number }[];
}

// ---------- Reviews ----------
export function listApprovedReviews(): ReviewRow[] {
  return db.prepare("SELECT * FROM reviews WHERE approved = 1 ORDER BY createdAt DESC").all() as ReviewRow[];
}

export function listPendingReviews(): ReviewRow[] {
  return db.prepare("SELECT * FROM reviews WHERE approved = 0 ORDER BY createdAt DESC").all() as ReviewRow[];
}

export function countPendingReviews(): number {
  return (db.prepare("SELECT COUNT(*) as c FROM reviews WHERE approved = 0").get() as { c: number }).c;
}

export function createReview(data: { userId?: string | null; name: string; body: string; rating: number }): ReviewRow {
  const id = randomUUID();
  const createdAt = new Date().toISOString();
  db.prepare(
    "INSERT INTO reviews (id, userId, name, body, rating, approved, createdAt) VALUES (?, ?, ?, ?, ?, 0, ?)"
  ).run(id, data.userId ?? null, data.name, data.body, data.rating, createdAt);
  return db.prepare("SELECT * FROM reviews WHERE id = ?").get(id) as ReviewRow;
}

export function approveReview(id: string) {
  db.prepare("UPDATE reviews SET approved = 1 WHERE id = ?").run(id);
}

export function deleteReview(id: string) {
  db.prepare("DELETE FROM reviews WHERE id = ?").run(id);
}

export function insertReviewSeed(data: { name: string; body: string; rating: number }) {
  const id = randomUUID();
  const createdAt = new Date().toISOString();
  db.prepare(
    "INSERT INTO reviews (id, userId, name, body, rating, approved, createdAt) VALUES (?, NULL, ?, ?, ?, 1, ?)"
  ).run(id, data.name, data.body, data.rating, createdAt);
}

export function countReviews(): number {
  return (db.prepare("SELECT COUNT(*) as c FROM reviews").get() as { c: number }).c;
}

// ---------- Comments ----------
export function listPendingCommentsWithQuestion() {
  return db
    .prepare(
      `SELECT cm.*, q.prompt as questionPrompt
       FROM comments cm JOIN questions q ON q.id = cm.questionId
       WHERE cm.approved = 0 ORDER BY cm.createdAt DESC`
    )
    .all() as (CommentRow & { questionPrompt: string })[];
}

export function countPendingComments(): number {
  return (db.prepare("SELECT COUNT(*) as c FROM comments WHERE approved = 0").get() as { c: number }).c;
}

export function approveComment(id: string) {
  db.prepare("UPDATE comments SET approved = 1 WHERE id = ?").run(id);
}

export function deleteComment(id: string) {
  db.prepare("DELETE FROM comments WHERE id = ?").run(id);
}
