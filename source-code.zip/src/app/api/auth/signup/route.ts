import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { findUserByEmail, createUser } from "@/lib/repo";
import { hashPassword, createSession } from "@/lib/auth";

const schema = z.object({
  name: z.string().trim().min(2, "Name is required"),
  email: z.string().trim().email(),
  phone: z.string().trim().min(7, "A valid phone number is required"),
  address: z.string().trim().min(5, "Address is required"),
  zelleAccount: z.string().trim().min(3, "Zelle account (email or phone) is required"),
  password: z.string().min(8, "Password must be at least 8 characters"),
});

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message || "Invalid input" },
      { status: 400 }
    );
  }
  const { name, email, phone, address, zelleAccount, password } = parsed.data;

  const existing = findUserByEmail(email);
  if (existing) {
    return NextResponse.json({ error: "An account with that email already exists" }, { status: 409 });
  }

  const passwordHash = await hashPassword(password);
  const user = createUser(email, passwordHash, { name, phone, address, zelleAccount });
  await createSession(user.id);

  return NextResponse.json({ ok: true });
}
