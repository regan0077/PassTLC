"use server";

import { revalidatePath } from "next/cache";
import {
  setUserSubscriptionStatus,
  setUserAccountStatus,
  deleteUser as repoDeleteUser,
} from "@/lib/repo";
import { requireAdmin } from "@/lib/auth";

export async function toggleSubscription(userId: string, currentStatus: string) {
  await requireAdmin();
  const next = currentStatus === "ACTIVE" ? "NONE" : "ACTIVE";
  setUserSubscriptionStatus(userId, next);
  revalidatePath("/admin/users");
}

export async function toggleAccountStatus(userId: string, currentStatus: string) {
  const admin = await requireAdmin();
  if (admin.id === userId) {
    // Admins can't disable their own account — that would lock them out.
    return;
  }
  const next = currentStatus === "DISABLED" ? "ACTIVE" : "DISABLED";
  setUserAccountStatus(userId, next);
  revalidatePath("/admin/users");
}

export async function deleteUserAction(userId: string) {
  const admin = await requireAdmin();
  if (admin.id === userId) {
    // Admins can't delete their own account from this screen.
    return;
  }
  repoDeleteUser(userId);
  revalidatePath("/admin/users");
}
