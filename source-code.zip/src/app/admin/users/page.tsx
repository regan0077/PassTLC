import { listUsers } from "@/lib/repo";
import { getCurrentUser } from "@/lib/auth";
import UsersView from "./UsersView";

export default async function AdminUsersPage() {
  const [users, currentUser] = await Promise.all([listUsers(200), getCurrentUser()]);
  return <UsersView users={users} currentUserId={currentUser?.id ?? null} />;
}
