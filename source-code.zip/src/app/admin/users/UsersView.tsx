"use client";

import { useMemo, useState } from "react";
import type { UserRow } from "@/lib/repo";
import ConfirmSubmitButton from "@/components/ConfirmSubmitButton";
import { toggleSubscription, toggleAccountStatus, deleteUserAction } from "./actions";

function StatusPill({ status }: { status: "ACTIVE" | "DISABLED" }) {
  return (
    <span
      className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-bold ${
        status === "ACTIVE" ? "bg-signal/10 text-signal" : "bg-alert/10 text-alert"
      }`}
    >
      {status === "ACTIVE" ? "Active" : "Disabled"}
    </span>
  );
}

function UserActions({ user, isSelf }: { user: UserRow; isSelf: boolean }) {
  return (
    <div className="flex flex-wrap gap-x-3 gap-y-1 font-body text-sm font-bold">
      <form action={toggleSubscription.bind(null, user.id, user.subscriptionStatus)}>
        <button type="submit" className="text-ink underline decoration-taxi decoration-2 underline-offset-2">
          {user.subscriptionStatus === "ACTIVE" ? "Revoke access" : "Grant access"}
        </button>
      </form>
      {!isSelf && (
        <>
          <form action={toggleAccountStatus.bind(null, user.id, user.accountStatus)}>
            <button type="submit" className={user.accountStatus === "DISABLED" ? "text-signal" : "text-alert"}>
              {user.accountStatus === "DISABLED" ? "Enable" : "Disable"}
            </button>
          </form>
          <form action={deleteUserAction.bind(null, user.id)}>
            <ConfirmSubmitButton
              className="text-alert"
              confirmMessage={`Permanently delete ${user.email}? This removes their account and history. This can't be undone.`}
            >
              Delete
            </ConfirmSubmitButton>
          </form>
        </>
      )}
      {isSelf && <span className="font-body text-xs text-slate">(you)</span>}
    </div>
  );
}

export default function UsersView({ users, currentUserId }: { users: UserRow[]; currentUserId: string | null }) {
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return users;
    return users.filter((u) =>
      [u.name, u.email, u.phone, u.address, u.zelleAccount]
        .filter(Boolean)
        .some((v) => v!.toLowerCase().includes(q))
    );
  }, [users, query]);

  return (
    <div>
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <h1 className="font-display text-2xl font-bold">Users</h1>
        <input
          type="search"
          placeholder="Search name, email, phone, address, Zelle…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="w-full rounded-sm border border-[#d7dbd9] bg-white px-3 py-2 font-body text-sm sm:w-80"
        />
      </div>
      <p className="mt-1 font-body text-xs text-slate">
        Showing {filtered.length} of {users.length}
      </p>

      {/* Mobile: stacked cards */}
      <div className="mt-4 flex flex-col gap-3 md:hidden">
        {filtered.map((u) => {
          const isSelf = u.id === currentUserId;
          return (
            <div key={u.id} className="card-flat p-4">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="font-bold">{u.name || "(no name)"}</div>
                  <div className="font-body text-sm text-slate">{u.email}</div>
                </div>
                <StatusPill status={u.accountStatus} />
              </div>
              <dl className="mt-3 grid grid-cols-2 gap-x-3 gap-y-1 font-body text-xs">
                <dt className="text-slate">Role</dt>
                <dd>{u.role}</dd>
                <dt className="text-slate">Phone</dt>
                <dd className="truncate">{u.phone || "—"}</dd>
                <dt className="text-slate">Address</dt>
                <dd className="truncate">{u.address || "—"}</dd>
                <dt className="text-slate">Zelle</dt>
                <dd className="truncate">{u.zelleAccount || "—"}</dd>
                <dt className="text-slate">Trial used</dt>
                <dd>{u.questionsAnswered}/50</dd>
                <dt className="text-slate">Subscription</dt>
                <dd>{u.subscriptionStatus}</dd>
                <dt className="text-slate">Joined</dt>
                <dd>{new Date(u.createdAt).toLocaleDateString()}</dd>
              </dl>
              <div className="mt-3 border-t border-[#d7dbd9] pt-3">
                <UserActions user={u} isSelf={isSelf} />
              </div>
            </div>
          );
        })}
        {filtered.length === 0 && <p className="font-body text-sm text-slate">No users match your search.</p>}
      </div>

      {/* Desktop / tablet: table */}
      <div className="mt-4 hidden overflow-x-auto md:block">
        <table className="w-full min-w-[900px] font-body text-sm">
          <thead>
            <tr className="border-b border-[#d7dbd9] text-left">
              <th className="py-2 pr-3">Name</th>
              <th className="pr-3">Email</th>
              <th className="pr-3">Phone</th>
              <th className="pr-3">Address</th>
              <th className="pr-3">Zelle</th>
              <th className="pr-3">Role</th>
              <th className="pr-3">Trial</th>
              <th className="pr-3">Subscription</th>
              <th className="pr-3">Status</th>
              <th className="pr-3">Joined</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((u) => {
              const isSelf = u.id === currentUserId;
              return (
                <tr key={u.id} className="border-b border-[#d7dbd9] align-top">
                  <td className="py-2 pr-3 font-bold">{u.name || "—"}</td>
                  <td className="pr-3">{u.email}</td>
                  <td className="pr-3">{u.phone || "—"}</td>
                  <td className="max-w-[180px] truncate pr-3" title={u.address || undefined}>
                    {u.address || "—"}
                  </td>
                  <td className="pr-3">{u.zelleAccount || "—"}</td>
                  <td className="pr-3">{u.role}</td>
                  <td className="pr-3">{u.questionsAnswered}/50</td>
                  <td className="pr-3">{u.subscriptionStatus}</td>
                  <td className="pr-3">
                    <StatusPill status={u.accountStatus} />
                  </td>
                  <td className="pr-3 whitespace-nowrap">{new Date(u.createdAt).toLocaleDateString()}</td>
                  <td className="py-2">
                    <UserActions user={u} isSelf={isSelf} />
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {filtered.length === 0 && <p className="mt-4 font-body text-sm text-slate">No users match your search.</p>}
      </div>
    </div>
  );
}
