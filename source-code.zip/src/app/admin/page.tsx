import {
  countUsers,
  countActiveAccounts,
  countDisabledAccounts,
  countActiveSubscribers,
  countQuestions,
  countPendingReviews,
  countPendingComments,
} from "@/lib/repo";

export default async function AdminOverviewPage() {
  const activeSubscribers = countActiveSubscribers();

  const stats = [
    { label: "Total users", value: countUsers(), accent: "border-ink" },
    { label: "Active accounts", value: countActiveAccounts(), accent: "border-signal" },
    { label: "Disabled accounts", value: countDisabledAccounts(), accent: "border-alert" },
    { label: "Active subscribers", value: activeSubscribers, accent: "border-taxi" },
    { label: "Est. monthly revenue", value: `$${activeSubscribers * 20}`, accent: "border-taxi" },
    { label: "Questions in bank", value: countQuestions(), accent: "border-ink" },
    { label: "Pending reviews", value: countPendingReviews(), accent: "border-slate" },
    { label: "Pending comments", value: countPendingComments(), accent: "border-slate" },
  ];

  return (
    <div>
      <h1 className="font-display text-2xl font-bold">Overview</h1>
      <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className={`card-flat border-l-4 ${s.accent} p-4`}>
            <div className="font-body text-sm text-slate">{s.label}</div>
            <div className="mt-1 font-display text-2xl font-bold">{s.value}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
