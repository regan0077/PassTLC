import Link from "next/link";
import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";

export const metadata: Metadata = {
  robots: { index: false, follow: false },
};

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser();
  if (!user || user.role !== "ADMIN") {
    redirect("/signin");
  }

  return (
    <div className="container-page py-10">
      <div className="grid gap-8 md:grid-cols-[200px_1fr]">
        <aside className="font-body text-sm">
          <div className="font-display text-lg font-bold">Admin</div>
          <nav className="mt-4 flex flex-col gap-2">
            <Link href="/admin">Overview</Link>
            <Link href="/admin/questions">Questions</Link>
            <Link href="/admin/categories">Categories</Link>
            <Link href="/admin/users">Users</Link>
            <Link href="/admin/reviews">Reviews & comments</Link>
          </nav>
        </aside>
        <div>{children}</div>
      </div>
    </div>
  );
}
