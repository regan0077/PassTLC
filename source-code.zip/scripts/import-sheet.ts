import {
  upsertCategory,
  getCategoryBySlug,
  findQuestionByPrompt,
  createQuestion,
  updateQuestion,
} from "../src/lib/repo";

// Imports questions from a public Google Sheet into the local database.
//
// Sheet must have these exact column headers in row 1:
//   Category | Question | A | B | C | D | Answer | Explanation
//
// - Category: any text; becomes a category (auto-created, or matched to an
//   existing one by name).
// - A/B/C/D: the answer choices. Leave a cell blank to have fewer than 4
//   choices (at least 2 must be filled).
// - Answer: the letter of the correct choice (A, B, C, or D).
// - Explanation: optional.
//
// Usage:
//   npm run import:sheet
//   SHEET_ID=... SHEET_GID=... npm run import:sheet   (to point at a different sheet/tab)

const DEFAULT_SHEET_ID = "1TjtRoto-3WJZUQiJdgbAf3BLJh2I_9uE98krRrMleDc";
const SHEET_ID = process.env.SHEET_ID || DEFAULT_SHEET_ID;
const SHEET_GID = process.env.SHEET_GID || "0";
const CSV_URL = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/export?format=csv&gid=${SHEET_GID}`;

type Row = Record<string, string>;

// Minimal RFC4180 CSV parser: handles quoted fields, embedded commas,
// embedded newlines, and doubled-quote escaping ("").
function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let inQuotes = false;
  let i = 0;
  const push = () => {
    row.push(field);
    field = "";
  };
  const pushRow = () => {
    push();
    rows.push(row);
    row = [];
  };
  while (i < text.length) {
    const c = text[i];
    if (inQuotes) {
      if (c === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i += 2;
          continue;
        }
        inQuotes = false;
        i++;
        continue;
      }
      field += c;
      i++;
      continue;
    }
    if (c === '"') {
      inQuotes = true;
      i++;
      continue;
    }
    if (c === ",") {
      push();
      i++;
      continue;
    }
    if (c === "\r") {
      i++;
      continue;
    }
    if (c === "\n") {
      pushRow();
      i++;
      continue;
    }
    field += c;
    i++;
  }
  if (field.length > 0 || row.length > 0) pushRow();
  return rows.filter((r) => r.some((cell) => cell.trim() !== ""));
}

function toRows(csv: string[][]): Row[] {
  const [header, ...rest] = csv;
  return rest.map((r) => {
    const obj: Row = {};
    header.forEach((h, idx) => {
      obj[h.trim()] = (r[idx] ?? "").trim();
    });
    return obj;
  });
}

function slugify(name: string): string {
  return name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

async function main() {
  console.log(`Fetching sheet: ${CSV_URL}`);
  const res = await fetch(CSV_URL);
  if (!res.ok) {
    throw new Error(
      `Failed to fetch sheet (${res.status} ${res.statusText}). Make sure it's shared as "Anyone with the link can view".`
    );
  }
  const csvText = await res.text();
  const rows = toRows(parseCsv(csvText));

  if (rows.length === 0) {
    console.log("No data rows found in the sheet.");
    return;
  }

  const categorySortOrder = new Map<string, number>();
  let nextSortOrder = 0;

  let created = 0;
  let updated = 0;
  let skipped = 0;
  const skipReasons: string[] = [];

  for (const [i, row] of rows.entries()) {
    const rowNum = i + 2; // account for header row, 1-indexed sheet rows
    const categoryName = row["Category"];
    const prompt = row["Question"];
    const answerLetter = (row["Answer"] || "").trim().toUpperCase();
    const explanation = row["Explanation"] || undefined;

    if (!categoryName || !prompt) {
      skipped++;
      skipReasons.push(`Row ${rowNum}: missing Category or Question`);
      continue;
    }

    const letters: ("A" | "B" | "C" | "D")[] = ["A", "B", "C", "D"];
    const choicePairs = letters
      .map((l) => ({ letter: l, text: (row[l] || "").trim() }))
      .filter((c) => c.text !== "");

    if (choicePairs.length < 2) {
      skipped++;
      skipReasons.push(`Row ${rowNum}: fewer than 2 non-empty choices (A-D)`);
      continue;
    }

    const answerIndex = choicePairs.findIndex((c) => c.letter === answerLetter);
    if (answerIndex === -1) {
      skipped++;
      skipReasons.push(
        `Row ${rowNum}: Answer "${row["Answer"]}" doesn't match a filled choice letter (A-D)`
      );
      continue;
    }

    const slug = slugify(categoryName);
    let category = getCategoryBySlug(slug);
    if (!category) {
      const sortOrder = nextSortOrder++;
      categorySortOrder.set(slug, sortOrder);
      category = upsertCategory(slug, categoryName, `${categoryName} practice questions.`, sortOrder);
    }

    const choices = choicePairs.map((c) => c.text);
    const existing = findQuestionByPrompt(category.id, prompt);
    if (existing) {
      updateQuestion(existing.id, { choices, answer: answerIndex, explanation });
      updated++;
    } else {
      createQuestion({ categoryId: category.id, prompt, choices, answer: answerIndex, explanation });
      created++;
    }
  }

  console.log(`\nImport complete: ${created} created, ${updated} updated, ${skipped} skipped.`);
  if (skipReasons.length > 0) {
    console.log("\nSkipped rows:");
    skipReasons.forEach((r) => console.log(`  - ${r}`));
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
