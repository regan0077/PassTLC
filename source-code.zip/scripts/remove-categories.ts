import { getCategoryBySlug, deleteCategory } from "../src/lib/repo";

// One-off cleanup: removes categories (and their questions, via the
// questions.categoryId ON DELETE CASCADE foreign key) that are no longer
// part of the practice bank. Safe to re-run — skips slugs that don't exist.
const slugsToRemove = [
  "geography-1",
  "geography-2",
  "safe-driving",
  "tlc-rules-1",
  "tlc-rules-2",
];

function main() {
  for (const slug of slugsToRemove) {
    const category = getCategoryBySlug(slug);
    if (!category) {
      console.log(`Skipped (not found): ${slug}`);
      continue;
    }
    deleteCategory(category.id);
    console.log(`Removed category: ${category.name} (${slug})`);
  }
  console.log("Done.");
}

main();
